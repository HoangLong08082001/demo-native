import React from "react";
import style from "./UpdateTicket.module.scss";
import classNames from "classnames/bind";
const cx = classNames.bind(style);
export default function UpdateTicket() {
  return (
    <div className={cx("wrapper")}>
      <div>Update</div>
    </div>
  );
}
